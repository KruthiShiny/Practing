package overLoadRide;

public class calculate {
	public static void add(int a, int b)
	{
		int sum=a+b;
		System.out.println("result"+sum);
	}
	public static void add(int a,int b,int c) {
		int sum=a+b;
		int result=sum+c;
		System.out.println("output:"+result);
	}
	
	public static void main(String[]args) {
	add(10,20);
	add(10,20,30);
	
	

}
}

