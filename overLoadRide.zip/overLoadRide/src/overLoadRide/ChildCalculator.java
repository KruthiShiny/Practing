package overLoadRide;

public class ChildCalculator extends calculate{
	public static void subtract(int a, int b) {
		int difference=b-a;
		System.out.println(difference);
	}

public static void main(String[]args)
{
	ChildCalculator cal=new ChildCalculator();
	cal.add(100,200);
	cal.add(10,20,40);
	subtract(20,30);
}
}
